#!/bin/sh

java -classpath build:bin/* jade.Boot -gui Agent1:sin.MainAgent;