#!/bin/bash

mkdir -p libs
cd libs

wget www.stud.fit.vutbr.cz/~xkrasn06/jade.jar
wget www.stud.fit.vutbr.cz/~xkrasn06/commons-codec-1.3.jar

cd ..